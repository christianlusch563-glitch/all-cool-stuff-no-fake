# Mini Browser Proxy

This is a safe mini browser with a Proxy button.

The proxy only works with websites listed in `allowedHosts` inside `server.js`.

## How to run

1. Install Node.js.
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open:

```txt
http://localhost:3000
```

## Add allowed websites

Open `server.js` and add the website host to this list:

```js
const allowedHosts = [
  "example.com",
  "www.example.com"
];
```

Example:

```js
const allowedHosts = [
  "example.com",
  "www.example.com",
  "yourwebsite.com",
  "www.yourwebsite.com"
];
```

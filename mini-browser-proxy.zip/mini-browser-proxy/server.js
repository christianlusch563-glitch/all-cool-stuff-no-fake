const express = require("express");

const app = express();
const PORT = 3000;

// Only allow websites you trust.
// Add your own domains here.
const allowedHosts = [
  "example.com",
  "www.example.com",
  "developer.mozilla.org",
  "www.wikipedia.org",
  "wikipedia.org"
];

app.use(express.static(__dirname));

app.get("/proxy", async (req, res) => {
  try {
    const target = req.query.url;

    if (!target) {
      return res.status(400).send("Missing url.");
    }

    let parsedUrl;

    try {
      parsedUrl = new URL(target);
    } catch {
      return res.status(400).send("Invalid URL.");
    }

    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
      return res.status(400).send("Only HTTP and HTTPS are allowed.");
    }

    if (!allowedHosts.includes(parsedUrl.hostname)) {
      return res.status(403).send(`
        <h1>Blocked by safe proxy</h1>
        <p>This domain is not in your allowlist.</p>
        <p>Add this host to <code>allowedHosts</code> in server.js:</p>
        <code>${parsedUrl.hostname}</code>
      `);
    }

    const response = await fetch(parsedUrl.toString(), {
      headers: {
        "User-Agent": "MiniBrowser/1.0"
      }
    });

    const contentType = response.headers.get("content-type") || "text/plain";
    const body = await response.text();

    res.setHeader("Content-Type", contentType);
    res.send(body);
  } catch (error) {
    res.status(500).send("Proxy error: " + error.message);
  }
});

app.listen(PORT, () => {
  console.log("Mini Browser running at:");
  console.log("http://localhost:" + PORT);
});
